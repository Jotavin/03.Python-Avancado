strings = ['A', 'B', 'C', 'D', 'E', 'F', 'G'] # Lista de letras
palavra = ''

for letra in strings:
    palavra += letra

print(palavra) # Lista de letras juntas

# palavra += 1 # Erro